Crafty.c("Ddos", {
    init: function () {
        this.addComponent("2D, DOM, ddos, Collision")
        this.attr({x: 9 * Settings.poligon, y: 3 * Settings.poligon});
    },
});		